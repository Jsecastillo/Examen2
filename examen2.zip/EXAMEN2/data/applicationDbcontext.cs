using Microsoft.EntityFrameworkCore;

namespace TuProyecto.Models
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        // DbSet para la tabla Estudiantes
        public DbSet<Estudiante> Estudiantes { get; set; }
    }
}
