using Microsoft.AspNetCore.Mvc;
using TuProyecto.Models;
using System.Linq;

namespace TuProyecto.Controllers
{
    public class EstudiantesController : Controller
    {
        private readonly ApplicationDbContext _context;

        public EstudiantesController(ApplicationDbContext context)
        {
            _context = context;
        }

        // Acción para mostrar la lista de estudiantes
        public IActionResult Index()
        {
            var estudiantes = _context.Estudiantes.ToList();
            return View(estudiantes);
        }
    }
}
