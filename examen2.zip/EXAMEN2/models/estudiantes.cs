namespace TuProyecto.Models
{
    public class Estudiante
    {
        public int ID { get; set; }        // Clave primaria
        public string Nombre { get; set; }  // Nombre del estudiante
        public string Apellido { get; set; } // Apellido del estudiante
        public int Edad { get; set; }       // Edad del estudiante
        public string Correo { get; set; }  // Correo electrónico del estudiante
    }
}
